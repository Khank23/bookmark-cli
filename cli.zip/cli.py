import typer
import json
from pathlib import Path

# Initialize the Typer app
cli_app = typer.Typer()

# Define the path for the bookmarks file
BOOKMARKS_PATH = Path("bookmarks.json")

# Function to load bookmarks from the file
def fetch_bookmarks():
    if BOOKMARKS_PATH.exists():
        with open(BOOKMARKS_PATH, "r") as file:
            return json.load(file)
    return {}

# Function to save bookmarks to the file
def store_bookmarks(bookmarks_data):
    with open(BOOKMARKS_PATH, "w") as file:
        json.dump(bookmarks_data, file, indent=4)

# Command to add a new bookmark
@cli_app.command()
def create(title: str, link: str):
    '''Create a new bookmark with a title and link.'''
    bookmarks_data = fetch_bookmarks()
    bookmarks_data[title] = link
    store_bookmarks(bookmarks_data)
    typer.echo(f"Bookmark '{title}' successfully created and added to your collection.")

# Command to list all bookmarks
@cli_app.command()
def display():
    '''Retrieve a comprehensive list of all saved bookmarks.'''
    bookmarks_data = fetch_bookmarks()
    if not bookmarks_data:
        typer.echo("No bookmarks have been saved.")
        return
    typer.echo("Saved bookmarks:")
    for title, link in bookmarks_data.items():
        typer.echo(f"{title}: {link}")

# Command to delete a bookmark by title
@cli_app.command()
def remove(title: str):
    '''Delete a bookmark by its title.'''
    bookmarks_data = fetch_bookmarks()
    if title in bookmarks_data:
        del bookmarks_data[title]
        store_bookmarks(bookmarks_data)
        typer.echo(f"Bookmark '{title}' has been successfully deleted.")
    else:
        typer.echo(f"No bookmark found with the name '{title}'.")

# Command to display the help guide
@cli_app.command()
def guide():
    '''Show help on how to use the CLI.'''
    typer.echo("""
               Learn how to navigate Bookmarks CLI Software.
               =========

               Available Commands:
               1- Create [TITLE] [LINK] - Create a new bookmark with a title and link.
               2- Display - Show all stored bookmarks.
               3- Remove [TITLE] - Remove a bookmark by title.
               4- Guide - Display this usage guide.
               ==========
               """)

# Entry point of the CLI application
if __name__ == "__main__":
    cli_app()